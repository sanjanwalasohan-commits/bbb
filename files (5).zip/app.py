"""Exit Velocity Tracker: upload a swing video, get an estimated EV.

Run:  streamlit run app.py
"""
import tempfile

import cv2
import numpy as np
import pandas as pd
import streamlit as st
from ultralytics import YOLO

from tracker import find_contact_and_velocity, px_per_inch, speed_mph

PERSON, BALL = 0, 32  # COCO class ids: person, sports ball

st.set_page_config(page_title="EV Tracker", page_icon="⚾", layout="centered")
st.title("⚾ Exit Velocity Tracker")
st.caption("Upload a slo-mo swing video. The app finds the batter and the ball, then estimates exit velocity.")


@st.cache_resource(show_spinner="Loading detection model (first run downloads it)...")
def load_model(name):
    return YOLO(name)


# ---------------- Sidebar settings ----------------
with st.sidebar:
    st.header("Settings")
    height_in = st.number_input("Batter height (inches)", 48.0, 90.0, 70.0, 0.5)
    stance = st.slider("Stance height factor", 0.80, 1.00, 0.93, 0.01,
                       help="Batter in stance is a bit shorter than standing height.")
    fps_override = st.number_input("Video FPS (real capture rate)", 0.0, 1000.0, 0.0, 1.0,
                                   help="Leave 0 to use the file's FPS. iPhone slo-mo is usually 240 (or 120).")
    model_name = st.selectbox("Detection model", ["yolov8s.pt", "yolov8m.pt", "yolov8n.pt"],
                              help="Bigger = better at spotting a small, fast ball, but slower.")
    conf = st.slider("Detection confidence", 0.02, 0.50, 0.05, 0.01,
                     help="Low values catch the blurry ball but add false positives.")
    imgsz = st.select_slider("Detection resolution", [640, 960, 1280, 1600], value=1280)
    max_frames = st.number_input("Max frames to process", 60, 2000, 600, 20)
    cal = st.number_input("Calibration factor", 0.5, 2.0, 1.0, 0.01,
                          help="Multiplies the raw estimate. Tune it from the log below using your sensor.")

video = st.file_uploader("Swing video", type=["mp4", "mov", "m4v", "avi"])


# ---------------- Detection ----------------
def detect(path, model, imgsz, conf, max_frames):
    cap = cv2.VideoCapture(path)
    file_fps = cap.get(cv2.CAP_PROP_FPS)
    total = min(int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), max_frames)
    bar = st.progress(0.0, text="Detecting batter and ball...")
    person_heights, balls = [], {}
    i = 0
    while i < total:
        ok, frame = cap.read()
        if not ok:
            break
        r = model.predict(frame, imgsz=imgsz, conf=conf, classes=[PERSON, BALL], verbose=False)[0]
        best_ball, biggest_person = None, None
        for b in r.boxes:
            c, p = int(b.cls[0]), float(b.conf[0])
            x1, y1, x2, y2 = b.xyxy[0].tolist()
            if c == BALL and (best_ball is None or p > best_ball[2]):
                best_ball = ((x1 + x2) / 2, (y1 + y2) / 2, p)
            elif c == PERSON and (biggest_person is None or (y2 - y1) > biggest_person):
                biggest_person = y2 - y1
        if best_ball:
            balls[i] = best_ball
        if biggest_person and len(person_heights) < 40:  # early frames = batter before the swing
            person_heights.append(biggest_person)
        i += 1
        if i % 5 == 0:
            bar.progress(min(i / total, 1.0), text=f"Detecting batter and ball... frame {i}/{total}")
    cap.release()
    bar.empty()
    return file_fps, person_heights, balls


def render_track(path, frame_idx, pts):
    """Draw the tracked ball path on the contact frame."""
    cap = cv2.VideoCapture(path)
    cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
    ok, frame = cap.read()
    cap.release()
    if not ok:
        return None
    prev = None
    for _, x, y in pts:
        p = (int(x), int(y))
        cv2.circle(frame, p, 8, (0, 255, 0), 2)
        if prev:
            cv2.line(frame, prev, p, (0, 255, 255), 2)
        prev = p
    return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)


# ---------------- Main flow ----------------
if video:
    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as tmp:
        tmp.write(video.read())
        path = tmp.name

    if st.button("Analyze swing", type="primary"):
        model = load_model(model_name)
        file_fps, person_heights, balls = detect(path, model, imgsz, conf, int(max_frames))
        fps = fps_override or file_fps or 240.0

        if not person_heights:
            st.error("No batter detected. Make sure the full batter is in frame and well lit.")
        elif len(balls) < 4:
            st.error(f"Only found the ball in {len(balls)} frames. Try a lower confidence, a bigger model, "
                     "higher resolution, a brighter ball, or a plainer background.")
        else:
            result = find_contact_and_velocity(balls)
            if result is None:
                st.error("Couldn't find a clean contact moment in the ball track.")
            else:
                scale = px_per_inch(person_heights, height_in, stance)
                raw = speed_mph(result["velocity_px_per_frame"], fps, scale)
                final = raw * cal
                st.session_state["last"] = {"raw": raw, "final": final}

                c1, c2 = st.columns(2)
                c1.metric("Estimated exit velocity", f"{final:.1f} mph")
                c2.metric("Raw (uncalibrated)", f"{raw:.1f} mph")

                img = render_track(path, result["contact_frame"], result["points"])
                if img is not None:
                    st.image(img, caption=f"Tracked ball path after contact (frame {result['contact_frame']})")

                with st.expander("Details"):
                    st.write({
                        "FPS used": fps,
                        "Ball detections": len(balls),
                        "Pixels per inch (from batter height)": round(scale, 2),
                        "Ball speed (px/frame)": round(float(np.linalg.norm(result['velocity_px_per_frame'])), 2),
                        "Track fit error (px, lower is better)": round(result["rms_px"], 2),
                    })
                if not 20 <= final <= 125:
                    st.warning("That number looks off. Check FPS, batter height, and that the right ball was tracked.")

    # ---------------- Calibration log ----------------
    if "last" in st.session_state:
        st.subheader("Log this swing")
        sensor = st.number_input("Sensor EV (Blast/Rapsodo) in mph", 0.0, 140.0, 0.0, 0.1)
        if st.button("Add to log") and sensor > 0:
            st.session_state.setdefault("log", []).append(
                {"Sensor mph": sensor, "Raw estimate mph": round(st.session_state["last"]["raw"], 1)})

if st.session_state.get("log"):
    df = pd.DataFrame(st.session_state["log"])
    df["Error mph"] = (df["Raw estimate mph"] - df["Sensor mph"]).round(1)
    st.dataframe(df, use_container_width=True)
    factor = (df["Sensor mph"] / df["Raw estimate mph"]).mean()
    st.info(f"Average error: {df['Error mph'].abs().mean():.1f} mph. "
            f"Suggested calibration factor: **{factor:.2f}** (enter it in the sidebar).")
