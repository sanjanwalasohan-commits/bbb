"""Pure math for the exit velocity tracker (no UI, no ML imports)."""
import numpy as np

FTS_TO_MPH = 3600 / 5280  # feet/second -> miles/hour (0.6818...)


def fit_velocity(pts):
    """Least-squares velocity of points [[frame, x, y], ...].

    Returns (velocity_px_per_frame as np.array([vx, vy]), rms_residual_px).
    """
    pts = np.asarray(pts, float)
    if len(pts) < 2 or np.ptp(pts[:, 0]) == 0:
        return np.zeros(2), 0.0
    t = pts[:, 0]
    px = np.polyfit(t, pts[:, 1], 1)
    py = np.polyfit(t, pts[:, 2], 1)
    rx = pts[:, 1] - np.polyval(px, t)
    ry = pts[:, 2] - np.polyval(py, t)
    rms = float(np.sqrt(np.mean(rx**2 + ry**2)))
    return np.array([px[0], py[0]]), rms


def find_contact_and_velocity(balls, n_after=6, n_before=4):
    """Find the bat-ball contact and the ball's velocity right after it.

    balls: dict {frame_index: (cx, cy, ...)}
    Contact = the point where the ball's velocity changes the most between a
    short window before and a short window after, favoring clean straight-line
    motion (low residual) in both windows.

    Returns dict or None.
    """
    frames = sorted(balls)
    if len(frames) < 4:
        return None
    pts = np.array([[f, balls[f][0], balls[f][1]] for f in frames], float)

    best = None
    for k in range(1, len(pts) - 2):
        after = pts[k:k + n_after]
        if len(after) < 3:
            break
        # Reject windows with big gaps in time (likely stitching unrelated detections)
        if after[-1, 0] - after[0, 0] > 3 * n_after:
            continue
        before = pts[max(0, k - n_before):k]
        va, ra = fit_velocity(after)
        if len(before) >= 2:
            vb, rb = fit_velocity(before)
        else:
            vb, rb = np.zeros(2), 0.0
        score = np.linalg.norm(va - vb) / (1.0 + ra + rb)
        if best is None or score > best["score"]:
            best = {
                "score": float(score),
                "contact_frame": int(pts[k, 0]),
                "velocity_px_per_frame": va,
                "rms_px": float(ra),
                "points": after,
            }
    return best


def px_per_inch(person_heights_px, height_in, stance_factor=0.93):
    """Pixels per real-world inch from the batter's bounding-box height.

    stance_factor: a batter in their stance is a bit shorter than standing height.
    """
    h = float(np.median(person_heights_px))
    return h / (height_in * stance_factor)


def speed_mph(v_px_per_frame, fps, px_per_in):
    """Convert a pixel velocity vector to mph."""
    px_per_frame = float(np.linalg.norm(v_px_per_frame))
    ft_per_s = px_per_frame * fps / (px_per_in * 12.0)
    return ft_per_s * FTS_TO_MPH
